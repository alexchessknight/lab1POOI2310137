/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise4;

/**
 *
 * @author Alumno
 */
public class Exercise4 {

    public static void main(String[] args) {
        int x=1,y=2,z=3;
        if(x<y){
        System.out.println("####");}
        else{
            System.out.println("&&&&");
            System.out.println("****");
        }
}}
