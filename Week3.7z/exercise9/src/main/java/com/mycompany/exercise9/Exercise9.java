/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise9;

/**
 *
 * @author Alumno
 */
public class Exercise9 {

    public static void main(String[] args) {
        int x=1;int y=2;int z=3;
        if('x'>'y' || 66 > (int)('A')){
            System.out.println("#*#");
        }
    }
}
