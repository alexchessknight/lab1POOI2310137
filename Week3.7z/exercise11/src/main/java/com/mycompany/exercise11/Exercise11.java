/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise11;

/**
 *
 * @author Alumno
 */
public class Exercise11 {

    public static void main(String[] args) {
        int num=9;
        if (num>0 && num%2!=0){
            System.out.println("TRUE!!!");
        }else{
            System.out.println("FALSE!!!");
        }
    }
}
