/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercise1;

/**
 *
 * @author Alumno
 */
public class Exercise1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        if(6<6*5){
            System.out.println("Hello");
            System.out.println(" There");
        }else{
            System.out.println("Bye bye~");
        }
    }
    
}
