/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise7;

/**
 *
 * @author Alumno
 */
public class Exercise7 {

    public static void main(String[] args) {
        int x=1;int y=2;int z=3;
        if(x++>y++ || x-->0){
            z++;}
        else{
            z--;
            System.out.println(x+" "+y+" "+z);
        }
    }
}
