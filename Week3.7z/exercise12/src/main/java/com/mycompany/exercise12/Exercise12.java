/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise12;

/**
 *
 * @author Alumno
 */
public class Exercise12 {

    public static void main(String[] args) {
        int numA=6;int numB=4578;
        if(numA>0 && numB>0){
            System.out.println("True");
        }else{
            System.out.println("False");
        }
    }
}
