/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise2;

/**
 *
 * @author Alumno
 */
public class Exercise2 {

    public static void main(String[] args) {
        int x=1,y=2,z=3;
        if (x>y && x>z){
                System.out.println("1111");}
            else{
                System.out.println("2222");}
    }
}
