/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise10;

/**
 *
 * @author Alumno
 */
public class Exercise10 {

    public static void main(String[] args) {
        int x=1;int y=2;int z=3;
        if(x<z){
            System.out.println("*");
        }else if(x==z){
            System.out.println("&");
        }else{
            System.out.println("$");
        }
    }
}
