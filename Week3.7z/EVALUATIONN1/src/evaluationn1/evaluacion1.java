/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package evaluationn1;
import java.util.Scanner;

/**
 *
 * @author Alumno
 */
public class EVALUATIONN1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[]args){
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        int numDay;
        System.out.println("Insert a number of the week (1-7)");
        numDay=scanner.nextInt();
        /*if (numDay==1){
            System.out.println("I hate Mondays");
        }else if(numDay==2){
            System.out.println("Taco Tuesday");
        }else if(numDay==3){
            System.out.println("It's Wednesday, guys");
        }else if(numDay==4){
            System.out.println("Feliz jueves jejeje");
        }else if(numDay==5){
            System.out.println("Rebecca Black - Friday");
        }else if(numDay==6){
            System.out.println("Elsaturno");
        }else{
            System.out.println("Ve a misa, marrano");
        }*/
        switch(numDay){
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
            default:
                System.out.println("That ain't a number of week");
                break;
        }scanner.close();
    }
}
