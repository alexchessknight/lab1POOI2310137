/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise6;

/**
 *
 * @author Alumno
 */
public class Exercise6 {

    public static void main(String[] args) {
        int a1=100;int a2=200;
        if(a1>100 && a2<=200){
        System.out.println(a1+" "+a2+" "+(a1+a2));
        }else{
        System.out.println(a1+" "a2+" "+(2*a1-a2));}
    }
}
