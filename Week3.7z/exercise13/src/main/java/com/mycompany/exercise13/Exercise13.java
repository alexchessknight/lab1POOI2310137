/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exercise13;

/**
 *
 * @author Alumno
 */
public class Exercise13 {

    public static void main(String[] args) {
        int numA=-3;int numB=-347;
        if(numA>0 && numB>0){
            System.out.println("True");
        }else if(numA<0 && numB<0){
            System.out.println("True");
        }else{
            System.out.println("False");
        }
    }
}
